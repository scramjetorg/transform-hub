"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const scramjet = require("scramjet");
const JSONStream = require("JSONStream");
const fs = require("fs");
const mod = function (input, ffrom, fto) {
    this.on("test", () => console.error("Got test event"));
    return new Promise((resolve) => {
        fs.createReadStream(ffrom)
            .pipe(JSONStream.parse("*"))
            .pipe(new scramjet.DataStream())
            .do((names) => {
            console.log(`Hello ${names.name}!`);
        }).map((names) => {
            return `Hello ${names.name}! \n`;
        })
            .pipe(fs.createWriteStream(fto))
            .on("finish", () => {
            resolve();
        });
    });
};
exports.default = mod;
//# sourceMappingURL=index.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const scramjet = require("scramjet");
const JSONStream = require("JSONStream");
const fs = require("fs");
const mod = function (input, ffrom, fto) {
    this.on("test", () => console.error("Got test event"));
    return fs.createReadStream(ffrom)
        .pipe(JSONStream.parse("*"))
        .pipe(new scramjet.DataStream())
        .map((names) => {
        return `Hello ${names.name}! \n`;
    })
        .do((names) => {
        console.log(`Hello ${names.name}!`);
    })
        .pipe(fs.createWriteStream(fto));
};
exports.default = mod;
//# sourceMappingURL=index.js.map
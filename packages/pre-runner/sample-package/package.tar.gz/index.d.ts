import { InertApp } from "@scramjet/types";
declare const mod: InertApp;
export default mod;
